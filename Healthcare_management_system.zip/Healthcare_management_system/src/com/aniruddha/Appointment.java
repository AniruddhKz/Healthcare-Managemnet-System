package com.aniruddha;

public class Appointment {
	
	private String date;
	private String time;
	private Patient patient;
	
	public Appointment(String date, String time, Patient patient) {
		this.date=date;
		this.time=time;
		this.patient=patient;
		
		
		
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	@Override
	public String toString() {
		return "Appointment [date=" + date + ", time=" + time + ", patient=" + patient + "]";
	}

	
}
