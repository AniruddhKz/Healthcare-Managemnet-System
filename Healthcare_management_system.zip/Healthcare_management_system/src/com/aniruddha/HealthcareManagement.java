package com.aniruddha;

import java.util.Scanner;

public class HealthcareManagement {
	
	private Map<String, List<Appointment>> appointments;
	public HealthcareManagement() {
		appointments=new HashMap<>();
	}
	
	public void addAppointment(String doctorName, Appointment appointment) {
		if(!appointments.containskey(doctorName)) {
			appointments.put(doctorName, new ArrayList<>());
		}
		
		appointments.put(doctorName, new(appointment);
	}

	public List<Appointment> getAppointments(String doctorName){
		return appointments.getOrDefaulot{
			doctorName, new ArrayList<>());
		
	}
	public static void main(String[] args) {
		
		HealthcareManagement management=new HealthcareManagement();
		Scanner scan= new Scanner(System.in);
		System.out.println("hello ");
		
		while(true) {
			System.out.println(" application ");
			System.out.println(" enter choice ");
			int choice=scan.nextInt();
			scan.nextLine();
			
			switch(choice) {
			
			case1:
				System.out.println(" enter doctors Name ");
			String doctorName=scan.nextLine();
			
			
			Patients patient= new Patient(patientName, age, gender);
			Appointment appointment=new Appointment(date, time, patient);
			management.addAppointment(doctorName, appointment);
			System.out.println("Appointmnt......................  ");
			break;
			
			
			case2:
				System.out.println("Enter doctors Name ");
			     String doctorName=scan.nextLine();
			     List<Appointment> appointments=management.getAppointments(doctName);
			     if(appointments.isEmpty()) {
			    	 System.out.println(docName);
			    	 
			    	  }
			     else {
			    	 System.out.println(docName);
			    	 for(Appointment appl: appointments) {
			    		 System.out.println(appl);
			    	 }
			     }
			break;
			
			
			
			case3:
				System.out.println("exiting program ");
			System.exit(0);
			break;
			default:
				System.out.println(" invalid ");
				
			}
		}
	}
	
	
	

}
